﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.WebPages;
using System.ComponentModel.DataAnnotations;


namespace CoffeeMVC.Models
{
    public class Order
    {
        [Key]
        public string sOrderID { get; set; }
        public decimal dSize { get; set; }
        public string sSize { get; set; }
        public decimal dSugar { get; set; }
        public string sSugar { get; set; }
        public decimal dCream { get; set; }
        public string sCream { get; set; }
        public int count { get; set; }
        public decimal dCoffeeTotal { get; set; }
        public decimal dOrderTotal { get; set; }
        public IList<Order> Orders { get; set; }

        public static string GetSize(string price)
        {
            string strName=null;
            switch (price)
            {
                case "1.75":
                    strName = "SMALL";
                    break;
                case "2.00":
                    strName = "MEDIUM";
                    break;
                case "2.25":
                    strName = "LARGE";
                    break;
            }
            return strName;
        }

        public static string GetCream(string price)
        {
            string strName = null;
            switch (price)
            {
                case "0.50":
                    strName = "1 CREAMER";
                    break;
                case "1.00":
                    strName = "2 CREAMERS";
                    break;
                case "1.50":
                    strName = "3 CREAMERS";
                    break;
                default:
                    strName = "NO CREAM";
                    break;
            }
            return strName;
        }
        public static string GetSugar(string price)
        {
            string strName = null;
            switch (price)
            {
                case "0.25":
                    strName = "1 SUGAR";
                    break;
                case "0.50":
                    strName = "2 SUGARS";
                    break;
                case "0.75":
                    strName = "3 SUGARS";
                    break;
                default:
                    strName = "NO SUGAR";
                    break;
            }
            return strName;
        }

        public static decimal GetCoffeTotal(Order order)
        {
            decimal total = 0;
            total = order.dSize + order.dCream + order.dSugar;
            return total;
        }

        public static decimal GetOrderTotal(List<Order> orderLI)
        {
            decimal total = 0;

            foreach(var item in orderLI)
            {
                total = total + item.dCoffeeTotal;
            }
            return total;
        }

        public static string GetOrderID(List<Order> orderLI)
        {
            String tempOrderID= "0";
            orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
            if(orderLI != null)
            {
               tempOrderID  = orderLI.Count.ToString();
            }
            return tempOrderID;
        }

        public static decimal MakePayment(List<Order> orderLI, decimal dPayment)
        {
            decimal dChange = 0;
            orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
            if (orderLI != null)
            {
                decimal dMoney = dPayment;
                decimal dTotal = 0;
                dTotal = Order.GetOrderTotal(orderLI);
                dChange = dPayment - dTotal;
            }
            return dChange;
        }
        public static List<Order> ReorderIndex(List<Order> orderLI)
        {
            int iIndex = 0;
            foreach (Order item in orderLI)
            {
                item.sOrderID = iIndex.ToString();
                iIndex++;
            }
                return orderLI;
        }

    }
}