﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CoffeeMVC.Startup))]
namespace CoffeeMVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
        }
    }
}
