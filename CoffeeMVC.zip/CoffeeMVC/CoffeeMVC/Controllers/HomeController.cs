﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using CoffeeMVC.Models;

namespace CoffeeMVC.Controllers
{
    public class HomeController : Controller
    {
        List<Order> orderLI = new List<Order>();
        public ActionResult Index()
        {
            if (System.Web.HttpContext.Current.Session["OLI"] != null)
            {
                orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
                Order.ReorderIndex(orderLI);
            }

            ViewBag.OrderID = Order.GetOrderID(orderLI);
            ViewBag.Total = orderLI.Sum(x => x.dCoffeeTotal);
            return View(orderLI);
        }
        public ActionResult AddToOrder(string size, string sugar, string cream)
        {
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Index(Order thisOrder)
        {
            if (
                    Request.Form["ddlSize"].Contains("Choose") || 
                    Request.Form["ddlCream"].Contains("Choose") ||
                    Request.Form["ddlSugar"].Contains("How") ||
                    Request.Form["ddlCount"].Contains("How")
               )
            {
                return RedirectToAction("Index");
            }
            else
            {
                string size = Request.Form["ddlSize"];
                string cream = Request.Form["ddlCream"];
                string sugar = Request.Form["ddlSugar"];
                int count = Convert.ToInt16(Request.Form["ddlCount"]);

                string sizeDesc = Order.GetSize(size);
                string creamDesc = Order.GetCream(cream);
                string sugarDesc = Order.GetSugar(sugar);

                thisOrder.sSize = sizeDesc;
                thisOrder.sCream = creamDesc;
                thisOrder.sSugar = sugarDesc;
                thisOrder.dSize = Convert.ToDecimal(size);
                thisOrder.dCream = Convert.ToDecimal(cream);
                thisOrder.dSugar = Convert.ToDecimal(sugar);
                thisOrder.dCoffeeTotal = Order.GetCoffeTotal(thisOrder);
                thisOrder.count = count;

                if (System.Web.HttpContext.Current.Session["OLI"] != null)
                {
                    orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
                    thisOrder.sOrderID = Order.GetOrderID(orderLI);
                    int iRemove = 0;
                    bool bRemoveMe = false;

                    foreach (Order item in orderLI)
                    {
                        int iIndex = 0;
                        //user orders more than one of the same drink
                        if (item.sSize == thisOrder.sSize && item.sCream == thisOrder.sCream && item.sSugar == thisOrder.sSugar)
                        {
                            thisOrder.dCream = thisOrder.dCream + item.dCream;
                            thisOrder.dSugar = thisOrder.dSugar + item.dSugar;
                            thisOrder.count = thisOrder.count + item.count;
                            thisOrder.dCoffeeTotal = thisOrder.dCoffeeTotal + item.dCoffeeTotal;
                            thisOrder.dOrderTotal = Order.GetOrderTotal(orderLI);
                            iRemove = iIndex;
                            bRemoveMe = true;
                            break;
                        }
                        iIndex++;
                    }

                    if (bRemoveMe == true)
                    {
                        orderLI.RemoveAt(iRemove);
                    }

                }

                orderLI.Add(thisOrder);

                System.Web.HttpContext.Current.Session["OLI"] = orderLI;

                return RedirectToAction("Index");
            }
        }

        public ActionResult AddMoney()
        {
            if (System.Web.HttpContext.Current.Session["OLI"] != null)
            {
                orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
            }
            ViewBag.OrderID = Order.GetOrderID(orderLI);
            ViewBag.Total = orderLI.Sum(x => x.dCoffeeTotal);
            return View(orderLI);
        }

        [HttpPost]
        public ActionResult MakePayment()
        {
            if(Request.Form["tbPayment"] == "")
            {
                return RedirectToAction("AddMoney");
            }
            else
            {
                orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
                string pay = Request.Form["tbPayment"];
                decimal dPayment = Convert.ToDecimal(Request.Form["tbPayment"]);

                if(dPayment > Convert.ToDecimal(20.00))
                {
                    ViewBag.Message = "Do not add more than $20.00.";
                    return RedirectToAction("AddMoney");
                }

                //only allow user to enter amts of .05
                if (dPayment / Convert.ToDecimal(0.05) % 1 == 0)
                {
                    decimal dChange = Order.MakePayment(orderLI, dPayment);

                    if (dChange >= 0)
                    {
                        System.Windows.Forms.MessageBox.Show("Your change is: $" + dChange + ". Your order is being brewed." );
                        System.Web.HttpContext.Current.Session.RemoveAll();
                        return RedirectToAction("Index");
                    }
                    else if (dChange < 0)
                    {
                        dChange = (dChange * -1);
                        System.Windows.Forms.MessageBox.Show("Please add an additional $" + dChange);
                        return RedirectToAction("AddMoney");
                    }
                    else
                    {
                        return RedirectToAction("AddMoney");
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Please enter amounts in 0.05 increments");
                    return RedirectToAction("AddMoney");
                }
            }
        }

        public ActionResult RemoveFromSession(string sIndex)
        {
            int iIndex = Convert.ToInt16(sIndex);
            if (System.Web.HttpContext.Current.Session["OLI"] != null)
            {
                orderLI = (List<Order>)System.Web.HttpContext.Current.Session["OLI"];
                    orderLI.RemoveAt(iIndex);
            }
            return RedirectToAction("Index");
        }

        public ActionResult CancelOrder()
        {
            System.Web.HttpContext.Current.Session.RemoveAll();
            return RedirectToAction("Index");
        }
    }
}